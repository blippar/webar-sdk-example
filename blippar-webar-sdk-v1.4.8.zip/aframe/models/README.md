# Credits

## astronaut.glb

`astronaut.glb is` model file is not part of the webar sdk and is used only as an example and is sourced from Google's Poly https://poly.google.com/view/dLHpzNdygsg
which now moved to https://sketchfab.com/3d-models/low-poly-astronaut-9729169a50fc4827bf01676ff3968713

License:
SunnyChen753 (https://sketchfab.com/sunnychen753)
CC AttributionCreative Commons Attribution [Learn more](https://creativecommons.org/licenses/by/4.0/)

## milk_bottle_1l.glb

`milk_bottle_1l.glb` model file is not part of the webar sdk and is used only as an example and is sourced from
https://sketchfab.com/3d-models/organic-fresh-milk-bottle-1l-3f09f749a5ca431d89423417ae306da6

License:
robertrestupambudi (https://sketchfab.com/robertrestupambudi)
CC AttributionCreative Commons Attribution [Learn more](https://creativecommons.org/licenses/by/4.0/)

## MaterialsVariantsShoe.glb

`MaterialsVariantsShoe.glb` model file is not part of the webar sdk and is used only as an example and is sourced from https://github.com/KhronosGroup/glTF-Sample-Models/tree/master/2.0/MaterialsVariantsShoe/glTF-Binary

License:
Copyright 2020 Shopify, Inc.
CC BY 4.0 [Learn more](https://creativecommons.org/licenses/by/4.0/)