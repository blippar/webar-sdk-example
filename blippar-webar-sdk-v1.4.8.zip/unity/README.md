# Getting started with WebAR SDK Unity Plugin

- Complete guide to get started with Unity Plugin, please follow step by step guide to get started: [Blippar Unity Integration](https://support.blippar.com/hc/en-us/articles/9563617386003-Blippar-Unity-Integration)
- API Reference for Unity WebAR SDK plugin - [API Reference (C#)](https://support.blippar.com/hc/en-us/articles/9664263142547-API-Reference-C-Unity-WebAR-SDK-plugin-v1-0-11)
