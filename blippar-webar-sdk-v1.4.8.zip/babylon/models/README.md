# Credits

## milk_bottle_1l.glb

`milk_bottle_1l.glb` model file is not part of the webar sdk and is used only as an example and is sourced from
https://sketchfab.com/3d-models/organic-fresh-milk-bottle-1l-3f09f749a5ca431d89423417ae306da6

License:
robertrestupambudi (https://sketchfab.com/robertrestupambudi)
CC AttributionCreative Commons Attribution [Learn more](https://creativecommons.org/licenses/by/4.0/)

## astronaut.glb

`astronaut.glb is` model file is not part of the webar sdk and is used only as an example and is sourced from Google's Poly https://poly.google.com/view/dLHpzNdygsg
which now moved to https://sketchfab.com/3d-models/low-poly-astronaut-9729169a50fc4827bf01676ff3968713

License:
SunnyChen753 (https://sketchfab.com/sunnychen753)
CC AttributionCreative Commons Attribution [Learn more](https://creativecommons.org/licenses/by/4.0/)

## oscar_trophy.glb

`oscar_trophy.glb` mode file  is not part of the webar sdk and is used only as an example and is sourced from https://sketchfab.com/3d-models/oscar-trophy-a466f45896814d73b0a91e8fd26ab1af

License:
thegraphicsgeek (https://sketchfab.com/xbox80792)
CC BY 4.0 [Learn more](https://creativecommons.org/licenses/by/4.0/)
